import React from 'react';

const Cart = ({ cart, removeFromCart }) => {
  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Shopping Cart</h1>
      
      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <>
          <div style={{ marginBottom: '2rem' }}>
            {cart.map((item, index) => (
              <div key={index} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem', border: '1px solid #ddd', marginBottom: '0.5rem', borderRadius: '4px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <img src={item.image} alt={item.name} style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '4px' }} />
                  <div>
                    <h4>{item.name}</h4>
                    <p>{item.brand} - ₹{item.price.toLocaleString()}</p>
                  </div>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  style={{ padding: '0.5rem 1rem', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
          
          <div style={{ borderTop: '2px solid #333', paddingTop: '1rem' }}>
            <h3>Total: ₹{total.toLocaleString()}</h3>
            <button 
              style={{ padding: '1rem 2rem', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', fontSize: '1.1rem' }}
            >
              Checkout
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;