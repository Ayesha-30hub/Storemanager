import React from 'react';

const Home = ({ products, addToCart }) => {
  const featuredProducts = products.slice(0, 4);

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Welcome to Product Inventory</h1>
      <p>Discover amazing products from various categories</p>
      
      <h2>Featured Products</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
        {featuredProducts.map(product => (
          <div key={product.id} style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
            <img src={product.image} alt={product.name} style={{ width: '100%', height: '200px', objectFit: 'cover', borderRadius: '4px', marginBottom: '1rem' }} />
            <h3>{product.name}</h3>
            <p>Brand: {product.brand}</p>
            <p>Category: {product.category}</p>
            <p>₹{product.price.toLocaleString()}</p>
            <button 
              onClick={() => addToCart(product)}
              style={{ padding: '0.5rem 1rem', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px' }}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;