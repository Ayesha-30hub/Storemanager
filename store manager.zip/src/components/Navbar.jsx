import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = ({ cartCount }) => {
  return (
    <nav style={{ padding: '1rem', backgroundColor: '#333', color: 'white', position: 'fixed', top: 0, width: '100%', zIndex: 1000 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>Product Inventory</h2>
        <div style={{ display: 'flex', gap: '2rem' }}>
          <Link to="/" style={{ color: 'white', textDecoration: 'none' }}>Home</Link>
          <Link to="/inventory" style={{ color: 'white', textDecoration: 'none' }}>Inventory</Link>
          <Link to="/cart" style={{ color: 'white', textDecoration: 'none' }}>
            Cart ({cartCount})
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;