import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './Pages.jsx/Home';
import Cart from './Pages.jsx/Cart';
import Inventory from './Pages.jsx/Inventory';
import './App.css';

function App() {
  const [cart, setCart] = useState([]);
  const [products] = useState([
    { id: 1, name: "Smart TV", brand: "Samsung", price: 45000, category: "Electronics", image: "/images/tv.jpeg" },
    { id: 2, name: "Phone", brand: "Apple", price: 80000, category: "Electronics", image: "/images/phone.jpeg" },
    { id: 3, name: "Tablet", brand: "iPad", price: 35000, category: "Electronics", image: "/images/macbook.jpeg" },
    { id: 4, name: "Dates", brand: "Medjool", price: 500, category: "Food", image: "/images/dates.jpeg" },
    { id: 5, name: "Shoes", brand: "Nike", price: 8000, category: "Fashion", image: "/images/shoes.jpeg" },
    { id: 6, name: "Fan", brand: "Bajaj", price: 3500, category: "Appliances", image: "/images/fan.jpeg" },
    { id: 7, name: "Watch", brand: "Rolex", price: 250000, category: "Fashion", image: "/images/watch.jpeg" },
    { id: 8, name: "Dried Fruits", brand: "Premium Mix", price: 800, category: "Food", image: "/images/dryfruits.jpeg" }
  ]);

  const addToCart = (story) => {
    setCart([...cart, story]);
  };

  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  return (
    <Router>
      <div className="App" style={{ marginTop: '80px' }}>
        <Navbar cartCount={cart.length} />
        <Routes>
          <Route path="/" element={<Home products={products} addToCart={addToCart} />} />
          <Route path="/inventory" element={<Inventory products={products} addToCart={addToCart} />} />
          <Route path="/cart" element={<Cart cart={cart} removeFromCart={removeFromCart} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
